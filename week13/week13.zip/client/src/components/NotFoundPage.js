function NotFoundPage () {
    return (
        <div>
            <h1>404: This is not the webpage you are looking for</h1>
        </div>
    )
}

export default NotFoundPage